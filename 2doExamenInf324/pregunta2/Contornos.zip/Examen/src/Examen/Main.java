package Examen;

import java.awt.Graphics2D;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Main extends javax.swing.JFrame{

	BufferedImage Nueva_Imagen,imagen;
	int i,j,r,g,b,w,h;
	int[][] rojo,verde,azul,HorizontalR,VerticalR,HorizontalG,VerticalG,HorizontalB,VerticalB;
	int a[];    
	Color colorAuxiliar;
	public Main() {
		initComponents();
	}
	
	public int Verifica(int a,int b){
		int mat;
		if(a>b){
			mat=b;
		}
		else{
			mat=a;
		}

		return mat;
	}

	public void Inicializa(){
				
		Nueva_Imagen=new BufferedImage(imagen.getWidth(),imagen.getHeight(),BufferedImage.TYPE_INT_RGB) ;
		h=imagen.getHeight();
		w=imagen.getWidth();
		rojo=new int[w][h];
		verde=new int[w][h];
		azul=new int[w][h];
		HorizontalR=new int[w][h];
		HorizontalG=new int[w][h];
		HorizontalB=new int[w][h];
		VerticalR=new int[w][h];
		VerticalG=new int[w][h];
		VerticalB=new int[w][h];
		a=new int[w*h];
		for( i=0;i<imagen.getWidth();i++){
			for(j=0;j<imagen.getHeight();j++){
				colorAuxiliar=new Color(imagen.getRGB(i, j));

				r = colorAuxiliar.getRed();
				g= colorAuxiliar.getGreen();
				b = colorAuxiliar.getBlue();

				rojo[i][j]=r; 
				verde[i][j]=g; 
				azul[i][j]=b; 

			}
		}
	}
	
	
	public void OperacionHorizontal(){
		for( i=0;i<imagen.getWidth()-1;i++){
			for(j=0;j<imagen.getHeight();j++){
				HorizontalR[i][j]=Math.abs((rojo[i+1][j]-rojo[i][j]));
				HorizontalG[i][j]=Math.abs((verde[i+1][j]-verde[i][j]));
				HorizontalB[i][j]=Math.abs((azul[i+1][j]-azul[i][j]));
				Nueva_Imagen.setRGB(i, j,new Color(HorizontalR[i][j],HorizontalG[i][j],HorizontalB[i][j]).getRGB());
			}
		}

	}

	public void OperacionVertical(){
		for( i=0;i<imagen.getWidth();i++){
			for(j=0;j<imagen.getHeight()-1;j++){
				VerticalR[i][j]=Math.abs((rojo[i][j+1]-rojo[i][j]));
				VerticalG[i][j]=Math.abs((verde[i][j+1]-verde[i][j]));
				VerticalB[i][j]=Math.abs((azul[i][j+1]-azul[i][j]));
				Nueva_Imagen.setRGB(i, j,new Color(VerticalR[i][j],VerticalG[i][j],VerticalB[i][j]).getRGB());
			}
		}
	}

	public void ObtenerBordes(){
		// max{|P[i+1, j +1]−P[i, j]|+|P[i, j +1]−P[i+1, j]|,q−1}
		for( i=0;i<imagen.getWidth()-1;i++){
			for(j=0;j<imagen.getHeight()-1;j++){
				HorizontalR[i][j]=Math.abs((rojo[i+1][j+1]-rojo[i][j]));
				HorizontalG[i][j]=Math.abs((verde[i+1][j+1]-verde[i][j]));
				HorizontalB[i][j]=Math.abs((azul[i+1][j+1]-azul[i][j]));

			}
		}
		for( i=0;i<imagen.getWidth()-1;i++){
			for(j=0;j<imagen.getHeight()-1;j++){
				VerticalR[i][j]=Math.abs((rojo[i][j+1]-rojo[i+1][j]));
				VerticalG[i][j]=Math.abs((verde[i][j+1]-verde[i+1][j]));
				VerticalB[i][j]=Math.abs((azul[i][j+1]-azul[i+1][j]));
			}
		}

		for( i=0;i<imagen.getWidth();i++){
			for(j=0;j<imagen.getHeight();j++){

				r=Verifica(VerticalR[i][j]+HorizontalR[i][j],255);
				g=Verifica(VerticalG[i][j]+HorizontalG[i][j],255);
				b=Verifica(VerticalB[i][j]+HorizontalB[i][j],255);
				Nueva_Imagen.setRGB(i, j,new Color(r,g,b).getRGB());
			}
		}
	}

	public void Mostrar(){
		jLabelImagenResultado.setIcon(new ImageIcon(Nueva_Imagen));
	}

	private void initComponents() {

		jLabeltitulo1 = new javax.swing.JLabel();
		jLabeltitulo2 = new javax.swing.JLabel();
		jScrollPane2 = new javax.swing.JScrollPane();
		jLabelImagenOriginal = new javax.swing.JLabel();
		jScrollPane3 = new javax.swing.JScrollPane();
		jLabelImagenResultado = new javax.swing.JLabel();
		jMenuBar1 = new javax.swing.JMenuBar();
		jMenu1 = new javax.swing.JMenu();
		jMenuItem1 = new javax.swing.JMenuItem();
		jMenu2 = new javax.swing.JMenu();
		jMenuGradienteAprox = new javax.swing.JMenuItem();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("Deteccion de imagenes");

		jLabeltitulo1.setFont(new java.awt.Font("Tahoma", 1, 11));
		jLabeltitulo1.setForeground(new java.awt.Color(204, 0, 0));
		jLabeltitulo1.setText("Imagen Original");

		jLabeltitulo2.setFont(new java.awt.Font("Tahoma", 1, 11));
		jLabeltitulo2.setForeground(new java.awt.Color(204, 0, 0));
		jLabeltitulo2.setText("Imagen Resultante");

		jLabelImagenOriginal.setBackground(new java.awt.Color(255, 0, 0));
		jLabelImagenOriginal.setForeground(new java.awt.Color(255, 0, 102));
		jScrollPane2.setViewportView(jLabelImagenOriginal);

		jLabelImagenResultado.setForeground(new java.awt.Color(0, 51, 255));
		jScrollPane3.setViewportView(jLabelImagenResultado);
		

		jMenu1.setText("Archivo");

		jMenuItem1.setText("Abrir Imagen");
		jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem1ActionPerformed(evt);
			}
		});
		jMenu1.add(jMenuItem1);

		jMenuBar1.add(jMenu1);

		jMenu2.setText("Metodo");

		jMenuGradienteAprox.setText("Obteber Bordes");
		jMenuGradienteAprox.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuGradienteAproxActionPerformed(evt);
			}
		});
		jMenu2.add(jMenuGradienteAprox);

		jMenuBar1.add(jMenu2);

		setJMenuBar(jMenuBar1);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGap(248, 248, 248))
				.addGroup(layout.createSequentialGroup()
						.addGap(50, 50, 50)
						.addComponent(jLabeltitulo1)
						
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 453, Short.MAX_VALUE)
						.addComponent(jLabeltitulo2)
						.addGap(111, 111, 111))
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(layout.createSequentialGroup()
								.addContainerGap()
								.addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(18, 18, 18)
								.addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
				);
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jLabeltitulo1)
								.addComponent(jLabeltitulo2))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 398, Short.MAX_VALUE)
						.addContainerGap())
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
								.addContainerGap(42, Short.MAX_VALUE)
								.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
										.addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 369, Short.MAX_VALUE)
										.addComponent(jScrollPane2))
								.addGap(46, 46, 46)))
				);

		pack();
	}

	private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {
		JFileChooser selector=new JFileChooser();
		selector.setDialogTitle("Seleccione una imagen");
		FileNameExtensionFilter filtroImagen = new FileNameExtensionFilter("JPG &  BMP", "jpg", "bmp");
		selector.setFileFilter(filtroImagen);
		int flag=selector.showOpenDialog(null);
		if(flag==JFileChooser.APPROVE_OPTION){
			try {
				File imagenSeleccionada=selector.getSelectedFile();
				imagen= ImageIO.read(imagenSeleccionada);
			} catch (IOException e) {
			}
			
			BufferedImage originalImage = imagen;
			int type = originalImage.getType() == 0? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
	
			jLabelImagenOriginal.setIcon(new ImageIcon(imagen));
			Inicializa();  
		}
	}
	
	private void jMenuGradienteAproxActionPerformed(java.awt.event.ActionEvent evt) {
		ObtenerBordes();
		Mostrar();
	}


	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Main().setVisible(true);
			}
		});
	}

	
	private javax.swing.JLabel jLabelImagenOriginal;
	private javax.swing.JLabel jLabelImagenResultado;
	private javax.swing.JLabel jLabeltitulo1;
	private javax.swing.JLabel jLabeltitulo2;
	private javax.swing.JMenu jMenu1;
	private javax.swing.JMenu jMenu2;
	private javax.swing.JMenuBar jMenuBar1;
	private javax.swing.JMenuItem jMenuGradienteAprox;
	private javax.swing.JMenuItem jMenuItem1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JScrollPane jScrollPane3;

}
